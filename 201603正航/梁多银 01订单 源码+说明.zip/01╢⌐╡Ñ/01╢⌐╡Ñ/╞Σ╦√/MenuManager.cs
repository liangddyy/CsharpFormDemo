﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01订单.其他
{
    class MenuManager
    {
        public static string getNameAddOrder()
        {
            return "添加订单";
        }
    }
}
