﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _01订单.ado;


namespace _01订单.Factory
{
    class AdoFactory
    {
        public static InterfaceDate GetDateInstance(MyDbType dbtype)
        {
            if (dbtype == MyDbType.sql)
                return new SqlDate();
            return null;
        }
        public enum MyDbType
        {
            oracle = 1,
            mysql = 2,
            sql = 3,
        }
    }
}
