using _01����.business;
using _01����.interfere;

namespace _01����
{
    static class FactoryObject
    {
        public static InterfaceObject GetBusiness(string progId)
        {
            if (progId == "order")
                return new Business();

            return null;
        }
    }
}
