﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _01订单.interfere;

namespace _01订单.business
{
    class Business:InterfaceObject
    {
        public DataSet Select(string o_id)
        {
//            SqlCommand cmd = null;
//
//            cmd.Parameters.Add(new SqlParameter[]
//            {
//                new SqlParameter("@name", "Pudding"), new SqlParameter("@ID", "1")
//            });
            throw new NotImplementedException();
        }

        public void Save(DataSet dataset)
        {
            throw new NotImplementedException();
        }

        public void Delete(string[] ids)
        {
            throw new NotImplementedException();
        }
    }
}
