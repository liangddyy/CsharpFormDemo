﻿using System.Data;
using _01订单.info;

namespace _01订单.interfere
{
    public interface InterfaceObject
    {
        DataSet Select(string o_id);
        void Save(DataSet dataset);
        void Delete(string[] ids);
    }
}