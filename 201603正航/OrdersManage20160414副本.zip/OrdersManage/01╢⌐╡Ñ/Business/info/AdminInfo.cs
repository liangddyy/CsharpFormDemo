﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01订单.model
{
    class AdminInfo
    {
        public string userName { get; set; }
        public string userPwd { get; set; }
    }
}
