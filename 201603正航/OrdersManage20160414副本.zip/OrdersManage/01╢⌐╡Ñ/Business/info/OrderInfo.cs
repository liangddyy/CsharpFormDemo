﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01订单.info
{
    public class OrderInfo
    {
        private string o_id { get; set; }

    }
}
