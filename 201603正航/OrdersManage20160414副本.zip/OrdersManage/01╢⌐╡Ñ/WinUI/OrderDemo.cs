﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using _01订单.interfere;

namespace _01订单.ui
{
    public partial class OrderDemo : Form
    {
        private InterfaceObject bo = FactoryObject.GetBusiness("order");

        public OrderDemo()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }
    }
}
