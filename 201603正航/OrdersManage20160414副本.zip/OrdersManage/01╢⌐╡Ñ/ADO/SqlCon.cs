﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01订单.ado
{
    static class SqlCon
    {
        private static SqlConnection con=null;

        private static SqlConnection GetCon()
        {
            if (con == null)
            {
                string str = "data source=.\\sqlexpress;initial catalog=information;integrated security=sspi;";
                return new SqlConnection(str);
            }
            return con;
        }
    }
}
