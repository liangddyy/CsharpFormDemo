﻿using System.Data;

namespace _01订单.ado
{
    public interface InterfaceDate
    {
        bool exec(string sql);
        int findAllCount(string sql);
        DataTable getData(string sql, int topRow = -1);
    }
}