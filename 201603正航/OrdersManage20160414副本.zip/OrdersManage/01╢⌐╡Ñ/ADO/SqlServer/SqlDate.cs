﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01订单.ado
{
    class SqlDate: InterfaceDate
    {
        private SqlConnection _DataAccess;
        private IDbCommand command;
        protected IDbConnection DataAccess
        {
            get
            {
                if (_DataAccess == null)
                    _DataAccess = new SqlConnection("Data Source=(local);" + "Initial Catalog=order;Integrated Security=SSPI;");    //数据库
                if (_DataAccess.State == ConnectionState.Closed)
                    _DataAccess.Open();
                return _DataAccess;
            }
        }
        protected IDbCommand Command
        {
            get
            {
                if (command == null)
                    command = DataAccess.CreateCommand();
                return command;

            }
            set
            {
                command = value;
            }

        }

        public bool exec(string sql)
        {
            Command.CommandText = sql;
            return Command.ExecuteNonQuery() > 0;
        }

        public int findAllCount(string sql)
        {
            Command.CommandText = sql;
            return int.Parse(Command.ExecuteScalar().ToString());
        }

        public DataTable getData(string sql, int topRow)
        {
            if (topRow != -1)
            {
                int st = sql.IndexOf("select") + 7;
                Command.CommandText = sql.Insert(st, "top " + topRow + " ");
            }
            else
                Command.CommandText = sql;
            IDataReader reader = Command.ExecuteReader();
            DataTable table = new DataTable();
            table.Load(reader);
            return new DataTable();

        }
    }
}
