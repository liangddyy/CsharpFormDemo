   export QINIU_ACCESS_KEY=QWYn5TFQsLLU1pL5MFEmX3s5DmHdUThav9WyOWOm
   export QINIU_SECRET_KEY=Bxckh6FA-Fbs9Yt3i3cbKVK22UPBmAOHJcL95pGz
   export QINIU_TEST_BUCKET="csharpsdk"
   export QINIU_TEST_DOMAIN="csharpsdk.qiniudn.com"
